# User Registration and Login Bug Fixes

## Issues Identified:
1. Missing @Transactional on service methods - data not persisting
2. Phone validation pattern conflicts with optional field
3. Profile photo upload sequence timing issue
4. Lazy loading issues with cart/wishlist

## Fix Plan:

### Step 1: Fix UserService - Add @Transactional ✅ COMPLETED
- Add @Transactional annotation to saveUser method
- Add @Transactional(readOnly = true) to read methods

### Step 2: Fix User Model - Remove problematic validation ✅ COMPLETED
- Remove @Pattern from phone field or make it optional with proper message
- Changed from `@Pattern(regexp = "^[0-9]{10}$")` to `@Size(min = 10, max = 10)`

### Step 3: Fix WebController - Fix signup method ✅ COMPLETED
- Reorder user save and photo upload logic
- Ensure user is saved before photo upload
- Add proper error handling and verification

### Step 4: Fix CartService and WishlistService ✅ COMPLETED
- Already had proper @Transactional annotations

## Status:
- [x] Fix UserService with @Transactional
- [x] Fix User model validation
- [x] Fix WebController signup method
- [x] Fix CartService and WishlistService
- [ ] Test the fixes

